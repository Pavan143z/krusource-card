import React, { Component } from "react";
import "./App.css";
import Header from "./components/headernav";
import Login from "./components/pages1/login";
import ProfileDisplay from "./components/viewjobs"
import Cardio from "./components/card";
import Home from "./components/pages1/home";
import Profile from "./components/profilenav";
import Register from "./components/pages1/register";
import { BrowserRouter, Route, Link, Switch } from "react-router-dom";

class App extends Component {
  render() {
    return (
      <div>


        <BrowserRouter>
          <div>
            <Header />

            <div className="container">
              <Switch>
                <Route exact path="/home" component={Home} />
                <Route exact path="/login" component={Login} />
                <Route exact path="/register" component={Register} />
                <Route exact path="/profile" component={Profile} />
                <Route exact path="/viewjobs" component={ProfileDisplay} />
                <Route exact path="/card" component={Cardio} />
              </Switch>
            </div>
          </div>
        </BrowserRouter>
       
        
      </div>
    );
  }
}

export default App;
