// import React from 'react'

// export class Profile extends React.Component {
//     render(){

    
//   return (
//     <div>
//       I m from Profile.
//     </div>
//   )
// }
// }

// export default Profile;




import React from 'react';




import { BrowserRouter, Route, Link, Switch } from "react-router-dom";

export const Profile = () => {
  return (
    <BrowserRouter>
    <nav className="navbar navbar-expand-lg navbar-light bg-dark">
      <div className="container-fluid">
        <div className="navbar-header">
          {/* <Link className="navbar-brand" to="/">
           Business and Social Site 
          </Link> */}
        </div>

        <div
          className="collapse navbar-collapse"
          id="bs-example-navbar-collapse-1"
        >
          <ul className="nav navbar-nav">
            <li className="active">
              <Link to="/home">
                Home<span className="sr-only" />
              </Link>
            </li>

            <li>
              <Link to="/business">Business</Link>
            </li>

            <li>
              <Link to="/socialnetworks">Social Networks</Link>
            </li>

            <li>
              <Link to="/chat">Chat</Link>
            </li>

         </ul>

         <ul className="nav navbar-nav navbar-right">
            <li><Link to="/login">Signout</Link></li>
           </ul>

          <ul className="nav navbar-nav navbar-right">
            
          </ul>
        </div>
      </div>
    </nav>
    </BrowserRouter>
  );
};

export default Profile;

