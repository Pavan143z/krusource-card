import React from 'react';
import { register } from '../../serviceWorker';

export class Register extends React.Component {
    constructor()
    {
        super();
        this.state =
        {
            first_name:'',
            last_name:'',
            email:'',
            password:'',

        }
        this.onChange = this.onchange.bind(this)
        this.onSubmit = this.onSubmit.bind(this)
    }

        onChange(e)
        {
            this.setState({[e.target.name]:e.target.value})
        }

        onSubmit(e)
        {
            e.preventDefault()
            const User={

                    first_name:this.state.first_name,
                    last_name:this.state.last_name,
                    email:this.state.email,
                    password:this.state.password
            }
        

        register(user).then(res=>{
            
          if(res)
          {
              this.PaymentResponse.history.push('/profile');
          }

        })
    }

    render(){
  return (
    <div>
      
    </div>
  )
}
}

export default Register;
