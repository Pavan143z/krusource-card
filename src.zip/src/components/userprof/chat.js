import React from 'react'

export class Chat extends React.Component {
    render(){

    
  return (
    <div>
        <h3>
        I m from Chatting.
        </h3>
      
    </div>
  )
}
}

export default Chat;
