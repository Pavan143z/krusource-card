import React from 'react'

export class SocialNetworks extends React.Component {
    render(){

    
  return (
    <div>
        <h3>
      I m from social Networks.
      </h3>
    </div>
  )
}
}

export default SocialNetworks;
